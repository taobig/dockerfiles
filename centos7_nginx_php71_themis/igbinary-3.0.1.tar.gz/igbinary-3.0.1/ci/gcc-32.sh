#!/bin/sh
exec gcc-4.8 -m32 "$@"
